This is a Read me file to run the code on the Veloce Emulator

1)Import the Emulation folder on to the Veloce server.
2)Once inside the veloce server,  change the directory to Emulator folder directory in the terminal
3)Run the make file by using the command 'make'.
4)you will find the simulated results and result details on the Terminal .