This is a Read me file to Simulate the code in Questa sim

1)Import  the entire files in the  sequence as mentioned below  to the project created in questa sim.
a)CachePackage.sv  b)ProcAndCache.sv  c)CommonBus.sv  d)Cache.sv  e)TopHDL.sv  f)TopHVL.sv e) TopTB.sv
2) Select and Compile all the files at a time.
3)Select the module name 'TopTB' for simulation.